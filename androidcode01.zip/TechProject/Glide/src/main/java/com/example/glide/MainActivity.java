// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.glide;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView_net;
    private ImageView imageView_local;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView_net = (ImageView) findViewById(R.id.image_net);
        imageView_local = (ImageView) findViewById(R.id.image_local);
        //使用Glide加载网络图片
        Glide.with(this).load("http://inthecheesefactory.com/uploads/source/nestedfragment/fragments.png").into(imageView_net);

        //使用Glide加载本地图片
        Glide.with(this).load(R.mipmap.ic_launcher).into(imageView_local);
    }
}
