// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.corecomponent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class FirstActivity extends AppCompatActivity {
    //创建一个Button的成员变量
    private Button mFinishBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("tag","FirstActivity -- onCreate()");
        setContentView(R.layout.activity_first);

        //建立映射关系并添加点击事件
        mFinishBtn = (Button) findViewById(R.id.finish_btn);
        mFinishBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //关闭FirstActivity
                finish();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("tag","FirstActivity -- onStart()");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i("tag","FirstActivity -- onRestart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("tag","FirstActivity -- onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("tag","FirstActivity -- onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("tag","FirstActivity -- onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("tag","FirstActivity -- onDestroy()");
    }
}
