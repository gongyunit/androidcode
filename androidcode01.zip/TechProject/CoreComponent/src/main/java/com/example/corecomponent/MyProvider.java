// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.corecomponent;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.util.Log;

/**
 * Created by 18763 on 2017/1/14.
 */

public class MyProvider extends ContentProvider {
    //第一次创建ContentProvider时调用的方法
    @Override
    public boolean onCreate() {
        Log.i("tag","onCreate方法得到调用");
        return false;
    }

    //实现查询方法，该方法应该返回查询到的Cursor
    @Nullable
    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        Log.i("tag","查询方法被调用 selection 参数为： " + selection);
        return null;
    }

    //该方法的返回值代表了该ContentProvider所提供数据的MIME类型
    @Nullable
    @Override
    public String getType(Uri uri) {
        return null;
    }

    //实现插入方法，该方法应该返回新插入的记录的Uri
    @Nullable
    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    //实现删除方法，该方法应该返回被删除的记录条数
    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    //实现更新方法，该方法应该返回被更新的记录条数
    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
