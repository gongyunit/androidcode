// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.corecomponent;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    //创建一个Button的成员变量
    private Button mStartBtn;
    //发送广播的Button
    private Button mSendBtn;
    //创建一个Mybinder对象
    private MyBinder myBinder;
    //创建一个MyReceiver对象
    private MyReceiver myReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("tag","MainActivity -- onCreate()");
        setContentView(R.layout.activity_main);

        //启动MyService
        Intent serviceIntent = new Intent(MainActivity.this,MyService.class);
        startService(serviceIntent);

        //绑定服务
        Intent bindIntent = new Intent(MainActivity.this,BindService.class);
        bindService(bindIntent,MyServiceConnection, Context.BIND_AUTO_CREATE);

        //建立映射关系并添加点击事件
        mStartBtn = (Button) findViewById(R.id.activity_btn);
        mStartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //启动FirstActivity
                Intent intent = new Intent(MainActivity.this,FirstActivity.class);
                startActivity(intent);
            }
        });

        //注册广播接收者
        myReceiver = new MyReceiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.intent.action.MY_BROADCAST");
        registerReceiver(myReceiver, filter);

        //点击Button 发送广播
        mSendBtn = (Button) findViewById(R.id.send_btn);
        mSendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //发送广播
                Intent intent = new Intent("android.intent.action.MY_BROADCAST");
                //传递一个消息 内容为hello receiver.
                intent.putExtra("msg", "hello receiver.");
                sendBroadcast(intent);
            }
        });
    }

    private ServiceConnection MyServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.i("tag","服务绑定成功");
            //获取Binder对象
            myBinder = (MyBinder) service;
            //调用Binder对象中的方法 进行通信
            myBinder.printLog();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.i("tag","服务断开");
        }
    };
    @Override
    protected void onStart() {
        super.onStart();
        Log.i("tag","MainActivity -- onStart()");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i("tag","MainActivity -- onRestart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("tag","MainActivity -- onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("tag","MainActivity -- onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("tag","MainActivity -- onStop()");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.i("tag","MainActivity -- onNewIntent()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(MyServiceConnection);
        unregisterReceiver(myReceiver);
        Log.i("tag","MainActivity -- onDestroy()");
    }
}
