// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.corecomponent;

import android.os.Binder;
import android.util.Log;

/**
 * Created by 18763 on 2017/1/2.
 */

public class MyBinder extends Binder {
    //提供一个与调用者通信的方法
    public void printLog(){
        Log.i("tag","服务绑定成功，方法被调用");
    }
}
