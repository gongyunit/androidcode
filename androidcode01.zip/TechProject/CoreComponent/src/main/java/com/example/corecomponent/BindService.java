// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.corecomponent;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

public class BindService extends Service {

    @Override
    public IBinder onBind(Intent intent) {
        Log.i("tag","BindService -- onBind");
        return new MyBinder();
    }

}
