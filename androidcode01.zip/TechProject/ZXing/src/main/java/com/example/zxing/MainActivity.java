// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.zxing;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.zxing.WriterException;

public class MainActivity extends AppCompatActivity {

    /**
     * 用来显示二维码的ImageView
     */
    private ImageView qrImg;

    /**
     * 用于触发扫描二维码的按钮
     */
    private Button scanBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        qrImg = (ImageView) findViewById(R.id.qr_img);

        try {
            //生成二维码并显示
            qrImg.setImageBitmap(QRCodeUtil.createQRCodeBitmap("http://www.baidu.com"));
        } catch (WriterException e) {
            e.printStackTrace();
        }

        scanBtn = (Button) findViewById(R.id.scan);
        scanBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //打开扫描的界面
                Intent intent = new Intent(MainActivity.this,CaptureActivity.class);
                startActivityForResult(intent,0);
            }
        });
    }
}
