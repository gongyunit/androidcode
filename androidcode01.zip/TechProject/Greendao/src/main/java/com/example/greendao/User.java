// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.greendao;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Property;
import org.greenrobot.greendao.annotation.Generated;

/**
 * @Entity表示这个实体类会在数据库中生成对应的表，
 */
@Entity
public class User {
    //@Id表示该字段是id，该字段的数据类型为 Long
    @Id
    private Long id;
    //@Property则表示该属性将作为表的一个字段，其中nameInDb看名字就知道这个属性在数据库中对应的数据名称。
    @Property(nameInDb = "USERNAME")
    private String username;
    @Property(nameInDb = "PWD")
    private String pwd;
    @Generated(hash = 1790705928)
    public User(Long id, String username, String pwd) {
        this.id = id;
        this.username = username;
        this.pwd = pwd;
    }
    @Generated(hash = 586692638)
    public User() {
    }
    public Long getId() {
        return this.id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getUsername() {
        return this.username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getPwd() {
        return this.pwd;
    }
    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
}