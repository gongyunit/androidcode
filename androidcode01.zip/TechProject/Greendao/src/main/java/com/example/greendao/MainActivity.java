// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.greendao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import org.greenrobot.greendao.query.QueryBuilder;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    /**
     * 数据库的名字
     */
    private final String DBName = "greendao_test.db";
    //Button的成员变量
    private Button creatBtn;
    private Button addBtn;
    private Button delBtn;
    private Button delAllBtn;
    private Button modifyBtn;
    private Button queryBtn;
    private Button queryAllBtn;
    //操作user表的成员变量
    UserDao userDao = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        creatBtn = (Button) findViewById(R.id.create_sq);
        addBtn = (Button) findViewById(R.id.add_sq);
        delBtn = (Button) findViewById(R.id.del_sq);
        delAllBtn = (Button) findViewById(R.id.delall_sq);
        modifyBtn = (Button) findViewById(R.id.modify_sq);
        queryBtn = (Button) findViewById(R.id.query_one_sq);
        queryAllBtn = (Button) findViewById(R.id.query_all_sq);
        creatBtn.setOnClickListener(this);
        addBtn.setOnClickListener(this);
        delBtn.setOnClickListener(this);
        delAllBtn.setOnClickListener(this);
        modifyBtn.setOnClickListener(this);
        queryBtn.setOnClickListener(this);
        queryAllBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            //点击创建数据库的操作，如果已经创建过则默认不再创建 只是打开数据库 并获取操作user表的session
            case R.id.create_sq:
                //获取DaoMaster对象
                DaoMaster.DevOpenHelper devOpenHelper = new DaoMaster.DevOpenHelper(getApplicationContext(), DBName, null);
                DaoMaster daoMaster = new DaoMaster(devOpenHelper.getWritableDb());
                //获取DaoSession对象
                DaoSession daoSession = daoMaster.newSession();
                //获取UserDao对象
                userDao = daoSession.getUserDao();
                Log.i("tag", "create db");
                break;
            //点击增加数据的操作
            case R.id.add_sq:
                //添加一条数据 GreenDao一般默认将id字段作为唯一约束并自动增长 在添加数据时不要添加id相同的数据  否则会报错
                User user = new User();
                user.setPwd("123");
                user.setUsername("zhangsan");
                if (userDao != null) {
                    try {
                        userDao.insert(user);
                        Log.i("tag", "insert data in db");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                break;
            //点击删除某条数据的操作
            case R.id.del_sq:
                //删除id为1的数据
                if (userDao != null) {
                    userDao.deleteByKey(1l);
                    Log.i("tag", "delete data in db");
                }
                break;
            //点击删除全部数据的操作
            case R.id.delall_sq:
                //删除全部数据
                if (userDao != null) {
                    userDao.deleteAll();
                    Log.i("tag", "delete all data in db");
                }
                break;
            //点击修改数据的操作
            case R.id.modify_sq:
                //修改数据 将密码改为321
                User user1 = new User(1L, "zhangsan", "321");
                if (userDao != null) {
                    userDao.update(user1);
                    Log.i("tag", "update data in db");
                }
                break;
            //点击查询某条数据的操作
            case R.id.query_one_sq:
                //查询id为 1 的数据
                if (userDao != null) {
                    QueryBuilder<User> queryBuilder = userDao.queryBuilder();
                    queryBuilder.where(UserDao.Properties.Id.eq(1L));
                    User u = queryBuilder.unique();
                    if (u != null){
                        Log.i("tag", "id = " + u.getId() + "\n" + "username = " + u + "\n" + "pwd = " + u + "\n");
                    } else {
                        Log.i("tag","no this data ");
                    }
                }
                break;
            //点击查询全部数据的操作
            case R.id.query_all_sq:
                //查询全部数据
                if (userDao != null) {
                    List<User> users = userDao.loadAll();
                    if (users != null && users.size() > 0) {
                        for (int i = 0; i < users.size(); i++) {
                            Log.i("tag", "id = " + users.get(i).getId() + "\n" + "username = " + users.get(i).getUsername() + "\n" + "pwd = " + users.get(i).getPwd() + "\n");
                        }
                    } else {
                        Log.i("tag", "no data in db");
                    }
                }
                break;
        }
    }
}