// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.retrofit;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.IOException;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Path;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "MainActivity";
    private Button mBtnQuery;
    private TextView mTvResult;
    public static final String API_URL = "https://api.github.com";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    private void initView() {
        mBtnQuery = (Button) findViewById(R.id.btn_query);
        mTvResult = (TextView) findViewById(R.id.tv_result);

        mBtnQuery.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        query();
    }

    /**
     * 实体类
     */
    public static class Contributor {
        public final String login;
        public final int contributions;

        public Contributor(String login, int contributions) {
            this.login = login;
            this.contributions = contributions;
        }
    }

    /**
     * 定以接口 请求地址是API_URL + /repos/{owner}/{repo}/contributors
     * 需要带过去两个参数  一个是String owner 一个是String repo
     * 返回值是 List<Contributor>
     */
    public interface GitHub {
        @GET("/repos/{owner}/{repo}/contributors")
        Call<List<Contributor>> contributors(
                @Path("owner") String owner,
                @Path("repo") String repo);
    }

    private void query() {
        //1.创建Retrofit对象
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(API_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        //2.创建访问api的请求
        //最终的访问请求时：https://api.github.com/repos/square/retrofit/contributors
        GitHub github = retrofit.create(GitHub.class);
        Call<List<Contributor>> call = github.contributors("square", "retrofit");


        //3.发送请求 获取结果
        call.enqueue(new Callback<List<Contributor>>() {
            @Override
            public void onResponse(Call<List<Contributor>> call, Response<List<Contributor>> response) {
                String result = "";
                for (Contributor contributor : response.body()) {
                    result += contributor.login + " (" + contributor.contributions + ")" + '\n';
                }
                mTvResult.setText(result);
            }

            @Override
            public void onFailure(Call<List<Contributor>> call, Throwable t) {

            }
        });
    }
}
