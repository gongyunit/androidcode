// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.aidlb;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import com.example.aidla.IMyAidlInterface;

public class MainActivity extends AppCompatActivity {

    private IMyAidlInterface iMyAidlInterface;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindService();
    }

    /**
     * 绑定服务
     */
    private void bindService(){
        Intent mIntent = new Intent();
        mIntent.setAction("com.example.aidla.IMyAidlInterface");//你定义的service的action
        mIntent.setPackage("com.example.aidla");//这里你需要设置你应用的包名
        boolean is = bindService(mIntent, serviceConnection, BIND_AUTO_CREATE);
        Log.i("AIDLService", "bindService: "+is);
    }

    private ServiceConnection serviceConnection = new ServiceConnection() {

        @Override
        public void onServiceDisconnected(ComponentName name) {
            iMyAidlInterface = null;
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            // Stub.asInterface，获取接口
            iMyAidlInterface = IMyAidlInterface.Stub.asInterface(service);
            try {
                iMyAidlInterface.printLog("aldl 测试");
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    };
}
