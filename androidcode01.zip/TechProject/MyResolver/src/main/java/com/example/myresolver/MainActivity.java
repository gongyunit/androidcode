// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.myresolver;

import android.content.ContentResolver;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    //ContentResolver对象
    private ContentResolver mCResolver;
    //访问ContentProvider的Uri 其中前半部分content://是安卓规定的用法  后面com.example.contentprovider就是我们在清单文件AndroidManifest.xml中定义的MyProvider的
    //authorities值
    Uri uri = Uri.parse("content://com.example.contentprovider");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //获取ContentResolver对象
        mCResolver = getContentResolver();
        //调用ContentProvider的查询方法
        mCResolver.query(uri,null,"query_where",null,null);
    }
}
