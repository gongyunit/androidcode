// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.aidla;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

/**
 * Created by zhangshun on 2016/6/7. 
 */
public class AidlService extends Service {

    private MyBinder myBinder;

    /**
     *在onBind中返回Binder对象 
     */
    @Override
    public IBinder onBind(Intent intent) {
        return myBinder;
    }

    /**
     * 在onCreate中创建Binder对象 
     */
    @Override
    public void onCreate() {
        super.onCreate();
        myBinder = new MyBinder();
    }

    /**
     * 定义内部类继承自AIDL自动生成的Stub类 
     * 该类继承了 android.os.Binder 实现了 com.example.zhangshun.myapplication.aidl.IMyAidlInterface 
     */
    public class MyBinder extends IMyAidlInterface.Stub {

        @Override
        public void printLog(String s) throws RemoteException {
            Log.i("ALDLService", "printLog: AIDLTEST -- "+s);
        }
    }

}  