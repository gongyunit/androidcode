// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.basecomponentview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.ListView;

public class GridViewActivity extends AppCompatActivity {

    //写一个GridView的成员变量
    private GridView mGV;
    //写一个GridViewAdapter的成员变量
    private GridViewAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_view);

        //建立映射关系
        mGV = (GridView) findViewById(R.id.gridview);
        //设置GridView为3列
        mGV.setNumColumns(3);
        mAdapter = new GridViewAdapter();
        mGV.setAdapter(mAdapter);
    }
}
