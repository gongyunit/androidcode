// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.basecomponentview;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;

public class MainActivity extends AppCompatActivity {

    //写一个ListView的成员变量
    private ListView mLv;
    //写一个ListViewAdapter的成员变量
    private ListViewAdapter mAdapter;
    //写一个Button的成员变量，用来启动GridViewActivity
    private Button mGridViewBtn;
    //写一个Button的成员变量，用来弹出PopupWindow的对话框
    private Button mPWBtn;
    //写一个Button的成员变量，用来启动DialogActivity的对话框
    private Button mDialogBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //建立映射关系
        mLv = (ListView) findViewById(R.id.listview);
        //初始化ListViewAdapter
        mAdapter = new ListViewAdapter();
        //将mAdapter设置给ListView
        mLv.setAdapter(mAdapter);
        //建立映射关系
        mGridViewBtn = (Button) findViewById(R.id.gridview_btn);
        //添加点击事件
        mGridViewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //点击Button时启动GridViewActivity
                Intent intent = new Intent(MainActivity.this,GridViewActivity.class);
                startActivity(intent);
            }
        });

        //建立映射关系
        mPWBtn = (Button) findViewById(R.id.pop_btn);
        //添加点击事件
        mPWBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //弹出PopupWindow的对话框
                // 加载自定义的布局，作为显示的内容
                View contentView = LayoutInflater.from(MainActivity.this).inflate(
                        R.layout.popup_view, null);

                final PopupWindow popupWindow = new PopupWindow(contentView,
                        LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, true);
                //设置一个空背景 为了实现点击空白处让其消失（这应该是系统的一个bug  如果不设置就不能实现点击空白处消失）
                popupWindow.setBackgroundDrawable(new ColorDrawable(0x00000000));
                popupWindow.showAsDropDown(v);
            }
        });
        //建立映射关系
        mDialogBtn = (Button) findViewById(R.id.dialog_btn);
        //添加点击事件
        mDialogBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //点击Button时启动DialogActivity
                Intent intent = new Intent(MainActivity.this,DialogActivity.class);
                startActivity(intent);
            }
        });
    }
}
