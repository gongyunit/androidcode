// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.basecomponentview;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class DialogActivity extends AppCompatActivity {
    //写一个Button的成员变量
    private Button mAlertBtn;
    //写一个Button的成员变量
    private Button mProgressBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialog);
        //建立映射关系
        mAlertBtn = (Button) findViewById(R.id.alert_btn);
        //添加点击事件
        mAlertBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //点击时启动一个AlertDialog
                new AlertDialog.Builder(DialogActivity.this)
                        .setTitle("我是AlertDialog")
                        .setCancelable(true) //设置能对话框可以通过点击外部空白处或返回键消失
                        .setMessage("欢迎使用AlertDialog")
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //点击确定按钮后弹出提示,同时对话框会自动消失,因为设置了
                                //Toast是安卓系统提供的用来弹出短暂提示的吐丝弹窗
                                Toast.makeText(DialogActivity.this,"您点击了确定",Toast.LENGTH_SHORT).show();
                            }
                        })
                        .show();//显示对话框
            }
        });
        //建立映射关系
        mProgressBtn = (Button) findViewById(R.id.progress_btn);
        mProgressBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //点击时弹出一个ProgressDialog
                ProgressDialog.show(DialogActivity.this,"我是ProgressDialog","欢迎使用ProgressDialog")
                .setCancelable(true);//设置能对话框可以通过点击外部空白处或返回键消失
            }
        });
    }
}
