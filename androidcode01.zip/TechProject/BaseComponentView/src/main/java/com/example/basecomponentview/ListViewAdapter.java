// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.basecomponentview;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.zip.Inflater;

/**
 * Created by 18763 on 2016/12/25.
 */

public class ListViewAdapter extends BaseAdapter {

    //构造一个String类型的数组 里面有五条数据 用来给ListView填充数据
    private String[] mStrs = new String[]{"第一天学习","第二天学习","第三天学习","第四天学习","第五天学习","第六天学习","第七天学习","第八天学习","第九天学习"};
    @Override
    public int getCount() {
        //数据的条数
        return mStrs.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        //写一个ViewHolder的局部变量
        ViewHolder holder;
        if (convertView == null){
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item,null);
            //初始化ViewHolder
            holder = new ViewHolder();
            //将布局文件中的TextView的引用设置给ViewHolder的TextView
            holder.textview = (TextView) convertView.findViewById(R.id.textview);
            //将ViewHolder保存到converView的Tag容器中
            convertView.setTag(holder);
        } else {
            //将ViewHolder从converView的Tag容器中取出
            holder = (ViewHolder) convertView.getTag();
        }
        //将ListView中对应位置的Item上设置上对应数据源的具体数据
        holder.textview.setText(mStrs[position]);
        return convertView;
    }

    /**
     * ListView 条目一旦移除屏幕则销毁,移入屏幕就创建,如果ListView拖动的过快,垃圾回收器就要频繁的启动回收垃圾,
     * 如果回收不过来仍然可能内存溢出,为了解决这样的问题ListView提供了convertView和ViewHolder机制,
     * 可以复用移除屏幕的对象,减少了创建和销毁的过程,解决了问题
     */
    static class ViewHolder{

        //布局中只有一个TextView来显示数据
        private TextView textview;
    }
}
