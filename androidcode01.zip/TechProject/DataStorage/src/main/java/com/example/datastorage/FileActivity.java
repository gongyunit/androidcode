// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.datastorage;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

public class FileActivity extends AppCompatActivity {
    //Button对象
    private Button mSaveFile;
    private Button mReadFile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file);
        //建立Button的映射关系
        mSaveFile = (Button) findViewById(R.id.save_data_file);
        mSaveFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    //以追加的模式打开文件输入流
                    FileOutputStream fos = openFileOutput("my_file",MODE_APPEND);
                    //将FileOutputStream 包装成PrintStream
                    PrintStream ps = new PrintStream(fos);
                    //输出文件内容
                    ps.print("file storage data");
                    //关闭文件输出流
                    ps.close();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        });
        mReadFile = (Button) findViewById(R.id.read_data_file);
        mReadFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //打开文件输入流
                try {
                    FileInputStream fis = openFileInput("my_file");
                    byte[] buff = new byte[1024];
                    int hasRead = 0;
                    StringBuilder sb = new StringBuilder("");
                    //读取文件内容
                    while ((hasRead = fis.read(buff)) > 0){
                        sb.append(new String(buff,0,hasRead));
                    }
                    //关闭文件输入流
                    fis.close();
                    Log.i("tag","从文件读出的数据为：" + sb.toString());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
