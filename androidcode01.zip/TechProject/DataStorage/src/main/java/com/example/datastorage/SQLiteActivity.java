// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.datastorage;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class SQLiteActivity extends AppCompatActivity implements View.OnClickListener {

    //Button的成员变量
    private Button creatBtn;
    private Button addBtn;
    private Button delBtn;
    private Button modifyBtn;
    private Button queryBtn;
    //数据库的成员变量
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sqlite);
        creatBtn = (Button) findViewById(R.id.create_sq);
        addBtn = (Button) findViewById(R.id.add_sq);
        delBtn = (Button) findViewById(R.id.del_sq);
        modifyBtn = (Button) findViewById(R.id.modify_sq);
        queryBtn = (Button) findViewById(R.id.query_sq);
        creatBtn.setOnClickListener(this);
        addBtn.setOnClickListener(this);
        delBtn.setOnClickListener(this);
        modifyBtn.setOnClickListener(this);
        queryBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.create_sq:
                //创建数据库和表
                db = SQLiteDatabase.openOrCreateDatabase(getFilesDir().toString() + "/test.db", null);
                Log.i("tag","create db");
                //定义见表语句
                String sql = "create table if not exists user_info(_id integer primary key autoincrement,"
                        + " name varcher(255),"
                        + " pwd varcher(255))";
                //执行sql语句
                db.execSQL(sql);
                break;
            case R.id.add_sq:
                //添加数据
                if(db != null){
                    ContentValues values = new ContentValues();
                    values.put("name","zhangsan");
                    values.put("pwd","123456");
                    db.insert("user_info",null,values);
                }
                break;
            case R.id.del_sq:
                //删除数据
                if (db != null){
                    db.delete("user_info","name like ?",new String[]{"zhangsan"});
                }
                break;
            case R.id.modify_sq:
                //修改数据
                if (db != null){
                    ContentValues values = new ContentValues();
                    values.put("name","lisi");
                    values.put("pwd","654321");
                    db.update("user_info",values,"_id>?",new String[]{"2"});
                }
                break;
            case R.id.query_sq:
                //查询数据
                if(db != null){
                    Cursor cs = db.query("user_info",new String[]{"_id,name,pwd"},null,null,null,null,null);
                    while (cs.moveToNext()){
                        Log.i("tag","_id = " + cs.getString(0));
                        Log.i("tag","name = " + cs.getString(1));
                        Log.i("tag","pwd = " + cs.getString(2));
                    }
                    cs.close();
                }
                break;
        }
    }
}
