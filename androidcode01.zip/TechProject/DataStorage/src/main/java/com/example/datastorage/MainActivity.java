// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.datastorage;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    //SharedPreference对象
    private SharedPreferences mSp;
    //Button对象
    private Button mSave;
    private Button mRead;
    private Button mFileBtn;
    private Button mSQLiteBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //建立Button的映射关系
        mSave = (Button) findViewById(R.id.save_data);
        mSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //第一个参数是给你要使用的SharedPreference的名称，根据名称不同可以创建多个SharedPreference  第二个参数是SharedPreference的模式，
                //我们选择私有模式 表示只能我们自己应用程序用
                mSp = getSharedPreferences("my_sharedpreferences",MODE_PRIVATE);
                //获取编辑器
                SharedPreferences.Editor editor = mSp.edit();
                //写入Boolean型数据
                editor.putBoolean("key_boolean",true);
                //写入Int型数据
                editor.putInt("key_int",1);
                //写入String型数据
                editor.putString("key_string","hello");
                //提交保存
                editor.commit();
            }
        });
        mRead = (Button) findViewById(R.id.read_data);
        mRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //拿到sp对象
                mSp = getSharedPreferences("my_sharedpreferences",MODE_PRIVATE);
                //读取数据 第二个参数为默认值
                Boolean b = mSp.getBoolean("key_boolean",false);
                int i = mSp.getInt("key_int",0);
                String s = mSp.getString("key_string","no data");
                //通过日志打印出来
                Log.i("tag","b = " + b);
                Log.i("tag","i = " + i);
                Log.i("tag","s = " + s);
            }
        });

        mFileBtn = (Button) findViewById(R.id.file_test);
        mFileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,FileActivity.class);
                startActivity(intent);
            }
        });
        mSQLiteBtn = (Button) findViewById(R.id.sqlite_test);
        mSQLiteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,SQLiteActivity.class);
                startActivity(intent);
            }
        });
    }
}
