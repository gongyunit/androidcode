// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.techproject;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity1 extends AppCompatActivity implements View.OnClickListener{

    //写一个TextView的成员变量
    private TextView mTV;
    //写一个EditText的成员变量
    private EditText mET;
    //写一个Button的成员变量
    private Button mBtn;
    //写一个ImageView的成员变量
    private ImageView mImg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //将mTV与布局文件中的TextView建立映射关系
        mTV = (TextView) findViewById(R.id.content_TV);
        //动态设置TextView要展示的内容
        mTV.setText("TextView 学习");

        //将mET与布局文件中的EditText建立映射关系
        mET = (EditText) findViewById(R.id.content_ET);
        //获取EditText上输入的文本内容
        String content = mET.getText().toString();

        //将mBtn与布局文件中的Button建立映射关系
        mBtn = (Button) findViewById(R.id.click_Btn);
        //给Button设置点击事件
        /*mBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //点击后要做的事情在这里写代码
                mTV.setTextColor(Color.parseColor("#0000ff"));
            }
        });*/

        //将mImg与布局文件中的ImageView建立映射关系
        mImg = (ImageView) findViewById(R.id.pic_Img);
        //给ImageView设置一张背景图片
        //首先要找一张图片命名为test.png 并放在工程的res-mipmap下
        mImg.setImageResource(R.mipmap.test);
    }

    @Override
    public void onClick(View v) {
        //点击后在TextView上显示“点击事件”
        mTV.setText("点击事件");
    }
}
