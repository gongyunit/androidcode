// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.techproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class CheckAndRadioActivity extends AppCompatActivity {

    //写一个CheckBox的成员变量
    private CheckBox mCB;
    //写一个RadioButton的成员变量
    private RadioButton mRB;
    //写一个RadioGroup的成员变量
    private RadioGroup mRG;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_and_radio);
        //建立映射关系
        mCB = (CheckBox) findViewById(R.id.checkbox);
        mRB = (RadioButton) findViewById(R.id.radio_button);
        mRG = (RadioGroup) findViewById(R.id.radio_group);
    }
}
