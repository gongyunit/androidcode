// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.techproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.DatePicker;
import android.widget.TimePicker;

public class TimeActivity extends AppCompatActivity {

    //写一个TimePicker的成员变量
    private TimePicker mTP;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time);

        //将mTP与布局文件中的TimePicKer建立映射关系
        mTP = (TimePicker) findViewById(R.id.time_picker);
    }
}
