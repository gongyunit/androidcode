// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.techproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.DatePicker;

public class DateActivity extends AppCompatActivity {

    //写一个DatePicker的成员变量
    private DatePicker mDP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date);

        //将mDP与布局文件中的DatePicKer建立映射关系
        mDP = (DatePicker) findViewById(R.id.date_picker);
    }
}
