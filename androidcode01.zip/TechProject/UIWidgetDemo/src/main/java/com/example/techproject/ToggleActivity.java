// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.techproject;

        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.widget.ToggleButton;

public class ToggleActivity extends AppCompatActivity {

    //写一个ToggleButton的成员变量
    private ToggleButton mTB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toggle);
        //将mTB和布局文件中个ToggleButton建立映射关系
        mTB = (ToggleButton) findViewById(R.id.toggle_button);
    }
}
