// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.media;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    //Button对象
    private Button mAudioPlay;
    private Button mVideoPlay;
    private Button mAudioRecord;
    private Button mCamera;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //建立Button的映射关系
        mAudioPlay = (Button) findViewById(R.id.audio_play);
        mAudioPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent audioPlayIntent = new Intent(MainActivity.this,AudioPlayActivity.class);
                startActivity(audioPlayIntent);
            }
        });
        mVideoPlay = (Button) findViewById(R.id.video_play);
        mVideoPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent audioPlayIntent = new Intent(MainActivity.this,VideoPlayActivity.class);
                startActivity(audioPlayIntent);
            }
        });

        mAudioRecord = (Button) findViewById(R.id.audio_record);
        mAudioRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent audioPlayIntent = new Intent(MainActivity.this,AudioRecordActivity.class);
                startActivity(audioPlayIntent);
            }
        });
        mCamera = (Button) findViewById(R.id.camera);
        mCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent audioPlayIntent = new Intent(MainActivity.this,CameraActivity.class);
                startActivity(audioPlayIntent);
            }
        });
    }
}
