// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.media;

import android.media.MediaPlayer;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

import java.io.File;
import java.io.IOException;

public class VideoPlayActivity extends AppCompatActivity {
    //Button对象
    private Button mPrepare;
    private Button mPlayPause;
    private Button mStop;
    //VideoView对象
    private VideoView mVV;
    //MediaController对象 用来控制视频的播放暂停进度条等 系统API提供的
    private MediaController mMC;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_play);
        mVV = (VideoView) findViewById(R.id.videoview);
        mMC = new MediaController(this);
        //建立Button的映射关系
        mPrepare = (Button) findViewById(R.id.prepare);
        mPrepare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    //提前将test.mp4文件放到sdcard下
                    //读取sdcard要在清单文件中配置读取权限
                    Toast.makeText(VideoPlayActivity.this,Environment.getExternalStorageDirectory().getAbsolutePath(),Toast.LENGTH_SHORT).show();
                    File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/test.mp4");
                    if (file.exists()){
                        mVV.setVideoPath(file.getAbsolutePath());
                        mVV.setMediaController(mMC);
                        mMC.setMediaPlayer(mVV);
                        mVV.requestFocus();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        mPlayPause = (Button) findViewById(R.id.play_pause);
        mPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mVV.isPlaying()){
                    mVV.pause();
                }else {
                    mVV.start();
                }
            }
        });

        mStop = (Button) findViewById(R.id.stop);
        mStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mVV.stopPlayback();
            }
        });
    }
}
