// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.media;

import android.media.MediaPlayer;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.IOException;

public class AudioPlayActivity extends AppCompatActivity {
    //Button对象
    private Button mPrepare;
    private Button mPlayPause;
    private Button mStop;
    //MediaPlayer对象
    private MediaPlayer mMP;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_play);
        mMP = new MediaPlayer();
        //建立Button的映射关系
        mPrepare = (Button) findViewById(R.id.prepare);
        mPrepare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    //提前将test.mp3文件放到sdcard下
                    //读取sdcard要在清单文件中配置读取权限
                    mMP.setDataSource(Environment.getExternalStorageDirectory().getAbsolutePath()+"/test.mp3");
                    mMP.prepare();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        mPlayPause = (Button) findViewById(R.id.play_pause);
        mPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mMP.isPlaying()){
                    mMP.pause();
                }else {
                    mMP.start();
                }
            }
        });

        mStop = (Button) findViewById(R.id.stop);
        mStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMP.stop();
            }
        });
    }
}
