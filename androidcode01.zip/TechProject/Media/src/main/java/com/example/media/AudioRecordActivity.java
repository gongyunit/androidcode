// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.media;

import android.media.MediaRecorder;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;

public class AudioRecordActivity extends AppCompatActivity {

    //Button对象
    private Button mBeginRecord;
    private Button mStopRecord;

    //MediaRecorder对象
    private MediaRecorder mMR;
    //File对象
    private File sourceFile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_record);
        mBeginRecord = (Button) findViewById(R.id.record_begin);
        mBeginRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMR = new MediaRecorder();
                //设置录音来源  注意在清单文件添加权限 <uses-permission android:name="android.permission.RECORD_AUDIO"/>
                mMR.setAudioSource(MediaRecorder.AudioSource.MIC);
                //设置录音的声音输出格式
                mMR.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
                //设置输出文件
                sourceFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/test.mp3");
                mMR.setOutputFile(sourceFile.getAbsolutePath());
                //设置编码格式
                mMR.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
                try {
                    mMR.prepare();
                    mMR.start();
                } catch (IOException e) {
                    Log.e("tag", "startRecoding prepare() failed", e);
                }
            }
        });
        mStopRecord = (Button) findViewById(R.id.record_end);
        mStopRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (mMR != null) {
                        mMR.stop();
                        mMR.release();
                        mMR = null;
                    }
                } catch (Exception e) {
                    Log.e("tag", "stop Recoding error", e);
                }
            }
        });
    }
}
