// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.media;

import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class CameraActivity extends AppCompatActivity {

    //Button对象
    private Button mCameraBtn;
    //ImageView对象 用来显示拍照的照片
    private ImageView mImage = null;
    //系统参数
    private static final int PHOTO_PICKED_WITH_DATA = 3021;
    private static final int CAMERA_WITH_DATA = 3023;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);
        mImage = (ImageView)findViewById(R.id.image_view);

        mCameraBtn = (Button) findViewById(R.id.camera);
        mCameraBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //调用系统摄像头
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,CAMERA_WITH_DATA);
            }
        });
    }
    /***
     * 调用系统拍照后返回的结果处理
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode!=RESULT_OK)
            return;
        switch(requestCode){
            case CAMERA_WITH_DATA:
                //系统拍照后返回结果的处理
                final Bitmap photo = data.getParcelableExtra("data");
                if(photo!=null){
                    doCropPhoto(photo);
                }
            case PHOTO_PICKED_WITH_DATA:
                //系统剪切照片后结果处理
                Bitmap photo1 = data.getParcelableExtra("data");
                if(photo1!=null){
                    mImage.setImageBitmap(photo1);
                }
        }
    }

    /**
     * 调用系统进行照片剪切
     * @param data
     */
    protected void doCropPhoto(Bitmap data){
        Intent intent = getCropImageIntent(data);
        startActivityForResult(intent, PHOTO_PICKED_WITH_DATA);
    }

    /**
     * 系统剪切的具体参数配置
     * @param data
     * @return
     */
    public static Intent getCropImageIntent(Bitmap data) {
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setType("image/*");
        intent.putExtra("data", data);
        intent.putExtra("crop", "true");
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        intent.putExtra("outputX", 128);
        intent.putExtra("outputY", 128);
        intent.putExtra("return-data", true);
        return intent;
    }
}
