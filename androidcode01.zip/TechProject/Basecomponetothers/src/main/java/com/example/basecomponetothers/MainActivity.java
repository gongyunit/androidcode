// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.basecomponetothers;

import android.animation.ObjectAnimator;
import android.graphics.drawable.AnimationDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {
    //写一个ImageView的成员变量
    private ImageView mIV;

    //写一个ImageView的成员变量 用于演示补间动画
    private ImageView mTweenIV;

    //写一个Button的成员变量  用来演示属性动画
    private Button mProBtn;
    //写一个ProgressBar的成员变量  用来演示水平样式的进度条
    private ProgressBar mProgressBar;
    //写一个SeekBar的成员变量
    private SeekBar mSeekBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //建立映射关系
        mIV = (ImageView) findViewById(R.id.image);
        //获取帧动画对象 AnimationDrawable
        AnimationDrawable animDrawable=(AnimationDrawable)mIV.getBackground();
        //启动动画
        animDrawable.start();

        //建立映射关系
        mTweenIV = (ImageView) findViewById(R.id.image_tween);
        Animation animation = AnimationUtils.loadAnimation(MainActivity.this,R.animator.anim_tween);
        mTweenIV.startAnimation(animation);

        //建立映射关系
        mProBtn = (Button) findViewById(R.id.property_btn);
        mProBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //点击时对按钮的透明度做属性动画  透明度从0变到1
                ObjectAnimator oa = ObjectAnimator.ofFloat(mProBtn,"alpha",0f,1f);
                //动画在3s之内完成
                oa.setDuration(3000);
                //启动动画
                oa.start();
            }
        });

        //建立映射关系
        mProgressBar = (ProgressBar) findViewById(R.id.downloadbar);
        mProgressBar.setMax(100);
        mProgressBar.setProgress(20);

        //建立映射关系
        mSeekBar = (SeekBar) findViewById(R.id.seekbar);
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                Log.i("tag","当前进度为 " + progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                Log.i("tag","开始拖动");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Log.i("tag","停止拖动");
            }
        });
    }
}
