// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.network;

import android.util.Log;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

/**
 * Created by 18763 on 2017/1/15.
 */

public class ClientGetPostUtil {
    /**
     * 向指定的URL发送GET请求的方法
     * @param url 发送请求的URL
     * @return 返回结果
     */
    public static String get(String url){
        String result = "";
        BufferedReader reader = null;
        //创建一个HttpClient对象
        HttpClient client = new DefaultHttpClient();
        //创建一个HttpGet对象
        HttpGet get = new HttpGet(url);
        try {
            //发送get请求
            HttpResponse response = client.execute(get);
            HttpEntity entity = response.getEntity();
            if (entity != null){
                //读取服务器响应
                reader = new BufferedReader(new InputStreamReader(entity.getContent()));
                String line;
                while ((line = reader.readLine()) != null){
                    result += line;
                }
            }
        } catch (Exception e) {
            Log.i("tag","client get 请求出错");
            e.printStackTrace();
        } finally {
            if (reader != null){
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result;
    }

    /**
     * post请求的方法
     * @param url
     * @param params
     * @return
     */
    public static  String post(String url,List<NameValuePair> params){
        String result = "";
        BufferedReader reader = null;
        //创建一个HttpClient对象
        HttpClient client = new DefaultHttpClient();
        //创建一个HttpGet对象
        HttpGet get = new HttpGet(url);
        try {
            //发送post请求
            HttpPost post = new HttpPost(url);
            //设置请求参数
            post.setEntity(new UrlEncodedFormEntity(params, HTTP.UTF_8));
            HttpResponse response = client.execute(post);
            //如果服务器成功的返回响应
            if (response.getStatusLine().getStatusCode() == 200){
               result = EntityUtils.toString(response.getEntity());
            }
        } catch (Exception e) {
            Log.i("tag","client post 请求出错");
            e.printStackTrace();
        } finally {
            if (reader != null){
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result;
    }
}
