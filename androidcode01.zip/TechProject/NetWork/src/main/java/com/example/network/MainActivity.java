// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.network;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener{

    //Button成员变量
    private Button url_get;
    private Button url_post;
    private Button client_get;
    private Button client_post;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //建立映射关系
        url_get = (Button) findViewById(R.id.url_get);
        url_post = (Button) findViewById(R.id.url_post);
        client_get = (Button) findViewById(R.id.client_get);
        client_post = (Button) findViewById(R.id.client_post);

        url_get.setOnClickListener(this);
        url_post.setOnClickListener(this);
        client_get.setOnClickListener(this);
        client_post.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.url_get:
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        URLGetPostUtil.get("http://192.168.88.88:8888/login",null);
                    }
                }).start();
                break;
            case R.id.url_post:
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        URLGetPostUtil.post("http://192.168.88.88:8888/login","name=test");
                    }
                }).start();
                break;
            case R.id.client_get:
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        ClientGetPostUtil.get("http://192.168.88.88:8888/login");
                    }
                }).start();
                break;
            case R.id.client_post:
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        List<NameValuePair> params = new ArrayList<NameValuePair>();
                        params.add(new BasicNameValuePair("name","name"));
                        ClientGetPostUtil.post("http://192.168.88.88:8888/login",params);
                    }
                }).start();
                break;
        }
    }
}
