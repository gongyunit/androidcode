// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.butterknifetest;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by 18763 on 2017/3/26.
 */

public class ListViewAdapter extends BaseAdapter {

    private List<String> list;
    private Context context;

    public ListViewAdapter(Context context, List<String> list) {
        this.list = list;
        this.context = context;
    }
    @Override
    public int getCount() {
        return list==null ? 0 : list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.list_item, null);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.textview.setText(list.get(position));
        return convertView;
    }
    static class ViewHolder {
        /**
         * 使用ButterKnife引用控件
         */
        @BindView(R.id.item_textview)
        TextView textview;

        public ViewHolder(View view) {
            /**
             * 使用ButterKnife绑定View
             */
            ButterKnife.bind(this, view);
        }
    }
}
