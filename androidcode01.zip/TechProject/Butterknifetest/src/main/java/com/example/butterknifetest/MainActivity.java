// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.butterknifetest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {
    /**
     * 使用ButterKnife引用控件
     */
    @BindView(R.id.textview)
    TextView textView;
    /**
     * 使用ButterKnife引用控件
     */
    @BindView(R.id.listview)
    ListView listView;

    /**
     * 使用ButterKnife引用资源
     */
    @BindString(R.string.app_name)
    String textContent;

    /**
     * 使用ButterKnife添加onClick事件
     */
    @OnClick(R.id.button)
    public void click(){
        Toast.makeText(this,"button  click ",Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /**
         * 使用ButterKnife绑定Activity
         */
        ButterKnife.bind(this);

        textView.setText(textContent);
        List<String> list = new ArrayList<String>();
        list.add("A");
        list.add("B");
        list.add("C");
        list.add("D");
        ListViewAdapter adapter = new ListViewAdapter(this,list);
        listView.setAdapter(adapter);
    }
}
